"""Ein einzelner Backpropagation-Test gegen analytische Referenzgradienten.

Dateien neben diesem Skript:
    weights.npz, trainingsdaten.npz, expected_gradients.npz

Annahme: mlp.train(x_data, y_data) führt einen Backpropagation-Schritt
für das eine Trainingsbeispiel aus und gibt (dW, db) zurück.
Falls die train-Signatur anders ist, NUR die markierte Zeile anpassen.
Der Vergleich erfolgt mit den zurückgegebenen Gradienten, NICHT mit
Gewichtsdifferenzen nach einem Optimizer-Update.
"""
from pathlib import Path
import numpy as np

from custom_mlp.core.layer import DenseLayer, ActivationLayer
from custom_mlp.core.activation_function import ReLu, Softmax
from custom_mlp import Custom_MLP

path = Path(__file__).resolve().parent
np.set_printoptions(precision=10, suppress=True)

# Die Architektur wird beim load_model() durch die gespeicherte ersetzt.
mlp = Custom_MLP(5, [
    DenseLayer(4),
    ActivationLayer(ReLu()),
    DenseLayer(16),
    ActivationLayer(ReLu()),
    DenseLayer(2),
    ActivationLayer(Softmax()),
])
mlp.load_model(str(path / "weights.npz"))

with np.load(path / "trainingsdaten.npz") as data:
    x_data = data["x_data"]  # (1, 5)
    y_data = data["y_data"]  # (1, 2)

with np.load(path / "expected_gradients.npz") as data:
    expected = {key: data[key].copy() for key in data.files}

print("x_data:", x_data)
print("y_data:", y_data)

# EIN Trainingsbeispiel, EIN Backpropagation-Schritt.
# ADAPTER: Nur diese Zeile ändern, falls deine train()-Signatur
# z.B. einzelne Vektoren statt Arrays mit Batch-Dimension erwartet.
dW, db = mlp.train(x_data, y_data)

# Erwartet: dW und db sind Sequenzen mit je einem Array pro Dense-Layer,
# in der Reihenfolge Dense 0, Dense 1, Dense 2.
if len(dW) != 3 or len(db) != 3:
    raise ValueError("train() muss je 3 dW und 3 db zurückgeben.")

all_ok = True
for i in range(3):
    actual_w = np.asarray(dW[i])
    actual_b = np.asarray(db[i])
    reference_w = expected[f"dW_{i}"]
    reference_b = expected[f"db_{i}"]

    w_shape_ok = actual_w.shape == reference_w.shape
    b_shape_ok = actual_b.shape == reference_b.shape
    w_ok = w_shape_ok and np.allclose(actual_w, reference_w, rtol=1e-6, atol=1e-9)
    b_ok = b_shape_ok and np.allclose(actual_b, reference_b, rtol=1e-6, atol=1e-9)
    all_ok = all_ok and w_ok and b_ok

    print(f"\nDense {i}")
    print(f"dW: {'OK' if w_ok else 'FEHLER'} (Ist {actual_w.shape}, Soll {reference_w.shape})")
    print(f"db: {'OK' if b_ok else 'FEHLER'} (Ist {actual_b.shape}, Soll {reference_b.shape})")
    if w_shape_ok:
        print("max |dW-Differenz|:", np.max(np.abs(actual_w - reference_w)))
    if b_shape_ok:
        print("max |db-Differenz|:", np.max(np.abs(actual_b - reference_b)))
    if not w_ok:
        print("dW Ist:\n", actual_w)
        print("dW Soll:\n", reference_w)
    if not b_ok:
        print("db Ist:\n", actual_b)
        print("db Soll:\n", reference_b)

print("\nERGEBNIS:", "ALLE GRADIENTEN KORREKT" if all_ok else "ABWEICHUNGEN GEFUNDEN")
